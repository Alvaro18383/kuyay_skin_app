
# Kuyay Skin App

## Cómo ejecutar la app

1. Instala las dependencias:

```
pip install -r requirements.txt
```

2. Ejecuta la aplicación:

```
streamlit run app.py
```

La app se abrirá automáticamente en tu navegador.

## Usuarios de prueba

- Free: demo@free.com / 1234  
- Premium: demo@premium.com / 1234
